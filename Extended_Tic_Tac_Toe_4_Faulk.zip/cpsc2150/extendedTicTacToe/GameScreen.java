package cpsc2150.extendedTicTacToe;

import java.util.Scanner;

public class GameScreen {


    public static void main(String[] args) {

        //This aroud will be used to see if the player would like to play once again
        char aroud;

        //This Do loop is where The game takes place and is controlled by aroud
        do {

            int numPlayers = 2;
            int numRows = 3;
            int numCol = 3;
            int numToWin = 3;

            //THis block will get the number of players
            do{
                System.out.println("How many players?");
                Scanner P = new Scanner(System.in);
                numPlayers = P.nextInt();

                if(numPlayers > 10)
                {
                    System.out.println("Sorry, but number of players must be 10 or fewer.");
                }
                else if(numPlayers < 2)
                {
                    System.out.println("Sorry, but number of players must be 2 or more.");
                }
            }while(numPlayers > 10 || numPlayers < 2);


            //this block will get the players pieces
            char[] Player = new char[numPlayers];
            int count = 0;
            do{
                System.out.println("Enter the character to represent player " + count);
                Scanner D = new Scanner(System.in);
                char temp = D.next().charAt(0);
                boolean notGood = false;
                for (int i = 0; i < numPlayers; i++)
                {
                    notGood = (temp == Player[i]);
                    if(notGood)
                        i = 1000;
                }

                if(notGood)
                {
                    System.out.println(temp + " this is not a valid character!");
                }
                else
                {
                    Player[count] = temp;
                    count++;
                }



            }while(count < numPlayers);

            //This block will get the number of coulombs
            do{
                System.out.println("How many coulombs?");
                Scanner P = new Scanner(System.in);
                numCol = P.nextInt();

                if(numCol > 100)
                {
                    System.out.println("Sorry, but number of coulombs must be 100 or fewer.");
                }
                else if(numCol < 3)
                {
                    System.out.println("Sorry, but number of coulombs must be 3 or more.");
                }

            }while(numCol < 3 || numCol > 100);

            //This block will get the number of rows
            do{
                System.out.println("How many rows?");
                Scanner P = new Scanner(System.in);
                numRows = P.nextInt();

                if(numRows > 100)
                {
                    System.out.println("Sorry, but number of rows must be 100 or fewer.");
                }
                else if(numRows < 3)
                {
                    System.out.println("Sorry, but number of rows must be 3 or more.");
                }

            }while(numRows < 3 || numRows > 100);

            //This block will get the number of characters in a line to win
            do{
                System.out.println("How many in a row to win?");
                Scanner P = new Scanner(System.in);
                numToWin = P.nextInt();

                if(numToWin > 25 || numToWin > numCol || numToWin > numRows)
                {
                    System.out.println("Sorry, but number of rows in line to win must be 25 or less than given bounderys.");
                }
                else if(numToWin < 3)
                {
                    System.out.println("Sorry, but number of rows must be 3 or more.");
                }
            }while(numToWin > 25 || !(numToWin <= numCol && numToWin <= numRows) || numToWin < 3);

            char gameType = 'f';

            //This block will get the type of chart
            do{
                System.out.println("Would you like a Fast Game (F/f) or a Memory Efficient Game (M/m)?");
                Scanner D = new Scanner(System.in);
                gameType = D.next().charAt(0);

                if(!(gameType == 'f' || gameType == 'F') && !(gameType == 'm' || gameType == 'M'))
                {
                    System.out.println("Please enter (f or m)");
                }

            }while(!(gameType == 'f' || gameType == 'F') && !(gameType == 'm' || gameType == 'M'));


                //These are the main variables that will keep track game mechanics
                int turnCounter = 1; //whos turn it is
                int row = 0;         //their entered row
                int col = 0;         //their entered col
            //choses the type of board
            IGameBoard board; //this is the board
            if(gameType =='f' || gameType == 'F')
            {
                board = new GameBoard(numRows, numCol, numToWin);
            }
            else
            {
                board = new GameBaordMem(numRows, numCol, numToWin);
            }
                boolean winner = false; //sees if a winner is here
                boolean cat = false;    //sees if a cat has occured.

                //This doWhile loop is controlled by the Winner variable and continues so long as no one
                //has won or until a cat has occurred.
                do {
                    //This if block will check to see if the turns are odd or even if its even then player O goes
                    //if its odd then player X goes.


                    //this will be used to control if the value is valid
                    boolean isValid = false;


                    //This while block is controlled by the isValid variable,
                    //It will first print the board then it will ask for a row
                    //then a col. It will check if the cords are valid and will either
                    //place the piece or ask for another.
                    while (!(isValid)) {

                        //prints using to string
                        System.out.print(board.toString());

                        //gets your Row
                        System.out.println("Player " + Player[turnCounter % numPlayers] + " Please enter your ROW");
                        Scanner R = new Scanner(System.in);
                        row = R.nextInt();

                        //gets your col
                        System.out.println("Player " + Player[turnCounter % numPlayers] + " Please enter your Col");
                        Scanner C = new Scanner(System.in);
                        col = C.nextInt();

                        //creats a board positoin obj to be checked
                        BoardPosition pos = new BoardPosition(row, col);

                        //checks the pieces place
                        isValid = board.checkSpace(pos);

                        //if it is not a valid place then it will ask for it again.
                        //if it is valid then it will place the piece and check to see if its
                        //a win.
                        if (!isValid) {
                            System.out.println("That was not a valid place please try again.");
                        } else {

                            board.placeMarker(pos, Player[turnCounter % numPlayers]);
                            winner = board.checkForWinner(pos);

                        }//end of if

                    }// end of while valid loop

                    //incroments turn counter so next player will be asked to move.
                    turnCounter++;

                    //This if bolck will check to see if the following peice resulted in a draw
                    //if the draw is found to be true then it'll stop the game.
                    if (board.checkForDraw()) {
                        winner = true;
                        cat = true;
                    }
                } while (!winner);//till winner found

                //this block will print the screen then check if the outcome was a cat.
                //if it was not a cat then itll say you won
                //if it was a cat then itll say it was a draw
                System.out.print(board.toString());
                if (cat != true) {
                    System.out.println("You won!");
                } else {
                    System.out.println("Its a draw, ");
                }





            //This will prompt the player to enter if they would like to play again
            //if they say yes(y) the loop will start agian
            //if they say no(n) the loop will exit and the games will be over.
            System.out.println("Would you like to play Again? y/n");
            Scanner R = new Scanner(System.in);
            aroud = R.next().charAt(0);
        }while(aroud == 'y');
    }

}
