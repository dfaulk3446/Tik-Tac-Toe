package cpsc2150.extendedTicTacToe;

import cpsc2150.extendedTicTacToe.BoardPosition;
import cpsc2150.extendedTicTacToe.GameBaordMem;
import cpsc2150.extendedTicTacToe.IGameBoard;

import org.junit.*;

import static org.junit.Assert.*;
public class TestGameBoardMem {


    private IGameBoard makeboard(int numRow, int numCol, int numWin)
    {
        IGameBoard tester = new GameBaordMem(numRow, numCol, numWin);
        return tester;
    }

    private String makeExpected(int numRow, int numCol, char[][] values)
    {
        StringBuilder build = new StringBuilder();

        //This will build the top row allowing us to make the frame
        for(int a = 0; a < numCol; a++)
        {
            if(a == 0)
            {
                build.append("  ");
            }
            if(a<10)
                build.append("| ").append(a);
            else
                build.append("|"). append(a);
        }

        build.append("|\n");

        //This loop will build the frame and fill the grid with the inputs.
        for(int i = 0; i < numRow; i++)
        {

            if(i < 10)
                build.append(" ").append(i);
            else
                build.append(i);

            for(int j = 0; j<numCol; j++)
            {

                build.append("| ").append(values[i][j]);
            }
            build.append("|\n");
        }
        return build.toString();
    }


    @Test
    public void testConstructor_3_3_3()
    {
        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        IGameBoard tester = makeboard(row,col,win);

        assertEquals(tester.getNumRows(), row);
        assertEquals(tester.getNumCol(), col);
        assertEquals(tester.getNumToWin(), win);
        assertEquals(tester.toString(), makeExpected(row, col, values));

    }

    @Test
    public void testConstructor_4_5_3()
    {

        int row = 4;
        int col = 5;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        IGameBoard tester = makeboard(row,col,win);

        assertEquals(tester.getNumRows(), row);
        assertEquals(tester.getNumCol(), col);
        assertEquals(tester.getNumToWin(), win);
        assertEquals(tester.toString(), makeExpected(row,col,values));

    }

    @Test
    public void testConstructor_5_4_4()
    {


        int row = 5;
        int col = 4;
        int win = 4;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        IGameBoard tester = makeboard(row,col,win);

        assertEquals(tester.getNumRows(), row);
        assertEquals(tester.getNumCol(), col);
        assertEquals(tester.getNumToWin(), win);
        assertEquals(tester.toString(), makeExpected(row,col,values));

    }

    @Test
    public void testCheckSpace_empty()
    {


        int row = 5;
        int col = 4;
        int win = 4;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }



        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test = new BoardPosition(0,0);

        assertEquals(tester.checkSpace(test), true);
        assertEquals(tester.toString(), makeExpected(row,col,values));
    }

    @Test
    public void testCheckSpace_player1()
    {


        int row = 5;
        int col = 4;
        int win = 4;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = 'X';

        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test = new BoardPosition(0,0);
        tester.placeMarker(test, 'X');

        assertEquals(tester.checkSpace(test), false);
        assertEquals(tester.toString(), makeExpected(row,col,values));
    }

    @Test
    public void testCheckSpace_out_of_bounds()
    {



        int row = 5;
        int col = 4;
        int win = 4;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = 'X';

        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test1 = new BoardPosition(0,0);
        BoardPosition test2 = new BoardPosition(8,8);

        tester.placeMarker(test1, 'X');

        assertEquals(tester.checkSpace(test2),false);
        assertEquals(tester.toString(), makeExpected(row,col,values));
    }

    @Test
    public void testHorizontalWin_Left_to_Right()
    {
        boolean correct = true;



        char player = 'X';
        int row = 4;
        int col = 5;
        int win = 4;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = 'X';
        values[0][1] = 'X';
        values[0][2] = 'X';
        values[0][3] = 'X';

        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test1 = new BoardPosition(0,0);
        BoardPosition test2 = new BoardPosition(0,1);
        BoardPosition test3 = new BoardPosition(0,2);
        BoardPosition test4 = new BoardPosition(0,3);

        tester.placeMarker(test1, player);
        tester.placeMarker(test2, player);
        tester.placeMarker(test3, player);
        tester.placeMarker(test4, player);

        assertEquals(tester.checkHorizontalWin(test1, player), correct);
        assertEquals(tester.toString(), makeExpected(row,col,values));

    }

    @Test
    public void testHorizontalWin_Right_to_Left()
    {
        boolean correct = true;


        char player = 'X';
        int row = 4;
        int col = 5;
        int win = 4;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = 'X';
        values[0][1] = 'X';
        values[0][2] = 'X';
        values[0][3] = 'X';

        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test1 = new BoardPosition(0,0);
        BoardPosition test2 = new BoardPosition(0,1);
        BoardPosition test3 = new BoardPosition(0,2);
        BoardPosition test4 = new BoardPosition(0,3);

        tester.placeMarker(test1, player);
        tester.placeMarker(test2, player);
        tester.placeMarker(test3, player);
        tester.placeMarker(test4, player);

        assertEquals(tester.checkHorizontalWin(test4, player), correct);
        assertEquals(tester.toString(), makeExpected(row,col, values));

    }

    @Test
    public void testHorizontalWin_marker_in_Middle()
    {

        boolean correct = true;



        char player = 'X';
        int row = 4;
        int col = 5;
        int win = 4;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = 'X';
        values[0][1] = 'X';
        values[0][2] = 'X';
        values[0][3] = 'X';

        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test1 = new BoardPosition(0,0);
        BoardPosition test2 = new BoardPosition(0,1);
        BoardPosition test3 = new BoardPosition(0,2);
        BoardPosition test4 = new BoardPosition(0,3);

        tester.placeMarker(test1, player);
        tester.placeMarker(test2, player);
        tester.placeMarker(test3, player);
        tester.placeMarker(test4, player);

        assertEquals(tester.checkHorizontalWin(test2, player), correct);
        assertEquals(tester.toString(), makeExpected(row,col,values));
    }

    @Test
    public void testHorizontalWin_No_win()
    {
        boolean correct = true;



        char player = 'X';
        int row = 4;
        int col = 5;
        int win = 4;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = 'X';
        values[0][1] = 'X';
        values[0][2] = 'X';


        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test1 = new BoardPosition(0,0);
        BoardPosition test2 = new BoardPosition(0,1);
        BoardPosition test3 = new BoardPosition(0,2);


        tester.placeMarker(test1, player);
        tester.placeMarker(test2, player);
        tester.placeMarker(test3, player);


        assertEquals(tester.checkHorizontalWin(test3, player), !correct);
        assertEquals(tester.toString(), makeExpected(row,col,values));
    }

    @Test
    public void testVerticalWin_top_to_bottom()
    {
        boolean correct = true;
        char player = 'X';


        int row = 5;
        int col = 4;
        int win = 4;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = 'X';
        values[1][0] = 'X';
        values[2][0] = 'X';
        values[3][0] = 'X';

        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test1 = new BoardPosition(0,0);
        BoardPosition test2 = new BoardPosition(1,0);
        BoardPosition test3 = new BoardPosition(2,0);
        BoardPosition test4 = new BoardPosition(3,0);


        tester.placeMarker(test1, player);
        tester.placeMarker(test2, player);
        tester.placeMarker(test3, player);
        tester.placeMarker(test4, player);

        assertEquals(tester.toString(), makeExpected(row,col,values));

        assertEquals(tester.checkVerticalWin(test1, player), correct);

    }

    @Test
    public void testVerticalWin_bottom_to_top()
    {
        boolean correct = true;
        char player = 'X';


        int row = 5;
        int col = 4;
        int win = 4;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = 'X';
        values[1][0] = 'X';
        values[2][0] = 'X';
        values[3][0] = 'X';

        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test1 = new BoardPosition(0,0);
        BoardPosition test2 = new BoardPosition(1,0);
        BoardPosition test3 = new BoardPosition(2,0);
        BoardPosition test4 = new BoardPosition(3,0);


        tester.placeMarker(test1, player);
        tester.placeMarker(test2, player);
        tester.placeMarker(test3, player);
        tester.placeMarker(test4, player);

        assertEquals(tester.toString(), makeExpected(row,col,values));

        assertEquals(tester.checkVerticalWin(test4, player), correct);


    }

    @Test
    public void testVerticalWin_middle()
    {
        boolean correct = true;
        char player = 'X';


        int row = 5;
        int col = 4;
        int win = 4;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = 'X';
        values[1][0] = 'X';
        values[2][0] = 'X';
        values[3][0] = 'X';

        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test1 = new BoardPosition(0,0);
        BoardPosition test2 = new BoardPosition(1,0);
        BoardPosition test3 = new BoardPosition(2,0);
        BoardPosition test4 = new BoardPosition(3,0);


        tester.placeMarker(test1, player);
        tester.placeMarker(test2, player);
        tester.placeMarker(test3, player);
        tester.placeMarker(test4, player);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.checkVerticalWin(test2, player), correct);


    }

    @Test
    public void testVerticalWin_No_Win()
    {
        boolean correct = true;
        char player = 'X';


        int row = 5;
        int col = 4;
        int win = 4;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = 'X';
        values[1][0] = 'X';
        values[2][0] = 'X';


        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test1 = new BoardPosition(0,0);
        BoardPosition test2 = new BoardPosition(1,0);
        BoardPosition test3 = new BoardPosition(2,0);



        tester.placeMarker(test1, player);
        tester.placeMarker(test2, player);
        tester.placeMarker(test3, player);


        assertEquals(tester.toString(), makeExpected(row,col,values));

        assertEquals(tester.checkVerticalWin(test3, player), !correct);


    }

    @Test
    public void testDiagonalWin_No_win()
    {
        boolean correct = true;
        char player = 'X';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = player;
        values[2][2] = player;

        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test1 = new BoardPosition(0,0);
        BoardPosition test3 = new BoardPosition(2,2);

        tester.placeMarker(test1, player);
        tester.placeMarker(test3, player);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.checkDiagonalWin(test3, player), !correct);

    }

    @Test
    public void testDiagonalWin_TopLeft_to_BottomRight()
    {

        boolean correct = true;
        char player = 'X';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = player;
        values[1][1] = player;
        values[2][2] = player;
        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test1 = new BoardPosition(0,0);
        BoardPosition test2 = new BoardPosition(1,1);
        BoardPosition test3 = new BoardPosition(2,2);

        tester.placeMarker(test1, player);
        tester.placeMarker(test2, player);
        tester.placeMarker(test3, player);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.checkDiagonalWin(test1, player), correct);

    }

    @Test
    public void testDiagonalWin_TopRight_to_BottomLeft()
    {
        boolean correct = true;
        char player = 'X';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][2] = player;
        values[1][1] = player;
        values[2][0] = player;

        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test1 = new BoardPosition(0,2);
        BoardPosition test2 = new BoardPosition(1,1);
        BoardPosition test3 = new BoardPosition(2,0);

        tester.placeMarker(test1, player);
        tester.placeMarker(test2, player);
        tester.placeMarker(test3, player);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.checkDiagonalWin(test1, player), correct);

    }

    @Test
    public void testDiagonalWin_placemiddle_TR_BL()
    {
        boolean correct = true;
        char player = 'X';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][2] = player;
        values[1][1] = player;
        values[2][0] = player;

        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test1 = new BoardPosition(0,2);
        BoardPosition test2 = new BoardPosition(1,1);
        BoardPosition test3 = new BoardPosition(2,0);

        tester.placeMarker(test1, player);
        tester.placeMarker(test2, player);
        tester.placeMarker(test3, player);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.checkDiagonalWin(test2, player), correct);

    }

    @Test
    public void testDiagonalWin_BottomLeft_to_TopRight()
    {
        boolean correct = true;
        char player = 'X';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][2] = player;
        values[1][1] = player;
        values[2][0] = player;

        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test1 = new BoardPosition(0,2);
        BoardPosition test2 = new BoardPosition(1,1);
        BoardPosition test3 = new BoardPosition(2,0);

        tester.placeMarker(test1, player);
        tester.placeMarker(test2, player);
        tester.placeMarker(test3, player);

        assertEquals(tester.toString(), makeExpected(row,col,values));

        assertEquals(tester.checkDiagonalWin(test1, player), correct);


    }

    @Test
    public void testDiagonalWin_BottomRight_to_TopLeft()
    {         boolean correct = true;
        char player = 'X';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = player;
        values[1][1] = player;
        values[2][2] = player;
        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test1 = new BoardPosition(0,0);
        BoardPosition test2 = new BoardPosition(1,1);
        BoardPosition test3 = new BoardPosition(2,2);

        tester.placeMarker(test1, player);
        tester.placeMarker(test2, player);
        tester.placeMarker(test3, player);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.checkDiagonalWin(test3, player), correct);


    }

    @Test
    public void testDiagonalWin_placemiddle_TL_BR()
    {
        boolean correct = true;
        char player = 'X';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = player;
        values[1][1] = player;
        values[2][2] = player;
        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test1 = new BoardPosition(0,0);
        BoardPosition test2 = new BoardPosition(1,1);
        BoardPosition test3 = new BoardPosition(2,2);

        tester.placeMarker(test1, player);
        tester.placeMarker(test2, player);
        tester.placeMarker(test3, player);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.checkDiagonalWin(test2, player), correct);


    }

    @Test
    public void testCheckForDraw_full_of_players()
    {
        boolean correct = true;
        char player = 'X';
        char player2 = 'O';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }
        values[0][0] = player;
        values[0][1] = player2;
        values[0][2] = player;
        values[1][0] = player;
        values[1][1] = player2;
        values[1][2] = player2;
        values[2][0] = player2;
        values[2][1] = player;
        values[2][2] = player;

        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test1 = new BoardPosition(0,0);
        BoardPosition test2 = new BoardPosition(0,1);
        BoardPosition test3 = new BoardPosition(0,2);
        BoardPosition test4 = new BoardPosition(1,0);
        BoardPosition test5 = new BoardPosition(1,1);
        BoardPosition test6 = new BoardPosition(1,2);
        BoardPosition test7 = new BoardPosition(2,0);
        BoardPosition test8 = new BoardPosition(2,1);
        BoardPosition test9 = new BoardPosition(2,2);

        tester.placeMarker(test1, player);
        tester.placeMarker(test2, player2);
        tester.placeMarker(test3, player);
        tester.placeMarker(test4, player);
        tester.placeMarker(test5, player2);
        tester.placeMarker(test6, player2);
        tester.placeMarker(test7, player2);
        tester.placeMarker(test8, player);
        tester.placeMarker(test9, player);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.checkForDraw(), correct);


    }

    @Test
    public void testCheckForDraw_Empty_No_DRAW()
    {
        boolean correct = true;
        char player = 'X';
        char player2 = 'O';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }



        IGameBoard tester = makeboard(row,col,win);


        assertEquals(tester.toString(), makeExpected(row, col, values));
        assertEquals(tester.checkForDraw(), !correct);

    }

    @Test
    public void testCheckForDraw_Partial_fill_No_DRAW()
    {
        boolean correct = true;
        char player = 'X';
        char player2 = 'O';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }
        values[0][0] = player;
        values[0][1] = player2;
        values[0][2] = player;
        values[1][2] = player2;
        values[2][2] = player;


        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test1 = new BoardPosition(0,0);
        BoardPosition test2 = new BoardPosition(0,1);
        BoardPosition test3 = new BoardPosition(0,2);
        BoardPosition test6 = new BoardPosition(1,2);
        BoardPosition test9 = new BoardPosition(2,2);

        tester.placeMarker(test1, player);
        tester.placeMarker(test2, player2);
        tester.placeMarker(test3, player);
        tester.placeMarker(test6, player2);
        tester.placeMarker(test9, player);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.checkForDraw(), !correct);

    }

    @Test
    public void testCheckForDraw_One_move_Left_no_DRAW()
    {
        boolean correct = true;
        char player = 'X';
        char player2 = 'O';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }
        values[0][0] = player;
        values[0][1] = player2;
        values[0][2] = player;
        values[1][0] = player;
        values[1][1] = player2;
        values[1][2] = player2;
        values[2][0] = player2;
        values[2][1] = player;


        IGameBoard tester = makeboard(row,col,win);

        BoardPosition test1 = new BoardPosition(0,0);
        BoardPosition test2 = new BoardPosition(0,1);
        BoardPosition test3 = new BoardPosition(0,2);
        BoardPosition test4 = new BoardPosition(1,0);
        BoardPosition test5 = new BoardPosition(1,1);
        BoardPosition test6 = new BoardPosition(1,2);
        BoardPosition test7 = new BoardPosition(2,0);
        BoardPosition test8 = new BoardPosition(2,1);


        tester.placeMarker(test1, player);
        tester.placeMarker(test2, player2);
        tester.placeMarker(test3, player);
        tester.placeMarker(test4, player);
        tester.placeMarker(test5, player2);
        tester.placeMarker(test6, player2);
        tester.placeMarker(test7, player2);
        tester.placeMarker(test8, player);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.checkForDraw(), !correct);

    }

    @Test
    public void testWhatsAtPos_space()
    {

        boolean correct = true;
        char player = 'X';
        char player2 = 'O';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        BoardPosition test1 = new BoardPosition(0,0);

        IGameBoard tester = makeboard(row,col,win);

        assertEquals(tester.toString(), makeExpected(row,col, values));
        assertEquals(tester.whatsAtPos(test1), ' ');
    }

    @Test
    public void testWhatsAtPos_player()
    {
        boolean correct = true;
        char player = 'X';
        char player2 = 'O';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = player;

        BoardPosition test1 = new BoardPosition(0,0);

        IGameBoard tester = makeboard(row,col,win);

        tester.placeMarker(test1, player);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.whatsAtPos(test1), player);

    }

    @Test
    public void testWhatsAtPos_player2()
    {
        boolean correct = true;
        char player = 'X';
        char player2 = 'O';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = player2;

        BoardPosition test1 = new BoardPosition(0,0);

        IGameBoard tester = makeboard(row,col,win);

        tester.placeMarker(test1, player2);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.whatsAtPos(test1), player2);

    }

    @Test
    public void testWhatsAtPos_diff_row()
    {
        boolean correct = true;
        char player = 'X';
        char player2 = 'O';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[1][0] = player2;

        BoardPosition test1 = new BoardPosition(1,0);

        IGameBoard tester = makeboard(row,col,win);

        tester.placeMarker(test1, player2);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.whatsAtPos(test1), player2);

    }

    @Test
    public void testWhatsAtPos_diff_col()
    {
        boolean correct = true;
        char player = 'X';
        char player2 = 'O';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][1] = player2;

        BoardPosition test1 = new BoardPosition(0,1);

        IGameBoard tester = makeboard(row,col,win);

        tester.placeMarker(test1, player2);

        assertEquals(tester.toString(), makeExpected(row,col, values));
        assertEquals(tester.whatsAtPos(test1), player2);

    }

    @Test
    public void testIsPlayerAtPos_no_Player()
    {
        boolean correct = true;
        char player = 'X';
        char player2 = 'O';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        BoardPosition test1 = new BoardPosition(0,0);

        IGameBoard tester = makeboard(row,col,win);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.isPlayerAtPos(test1,player), !correct);

    }

    @Test
    public void testIsPlayerAtPos_Wrong_Player()
    {
        boolean correct = true;
        char player = 'X';
        char player2 = 'O';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = player;

        BoardPosition test1 = new BoardPosition(0,0);

        IGameBoard tester = makeboard(row,col,win);

        tester.placeMarker(test1,player);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.isPlayerAtPos(test1,player2), !correct);

    }

    @Test
    public void testIsPlayerAtPos_Right_Player()
    {
        boolean correct = true;
        char player = 'X';
        char player2 = 'O';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = player;

        BoardPosition test1 = new BoardPosition(0,0);

        IGameBoard tester = makeboard(row,col,win);

        tester.placeMarker(test1,player);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.isPlayerAtPos(test1,player), correct);

    }

    @Test
    public void testIsPlayerAtPos_Wrong_Player2()
    {
        boolean correct = true;
        char player = 'X';
        char player2 = 'O';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = player2;

        BoardPosition test1 = new BoardPosition(0,0);

        IGameBoard tester = makeboard(row,col,win);

        tester.placeMarker(test1,player2);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.isPlayerAtPos(test1,player), !correct);

    }

    @Test
    public void testIsPlayerAtPos_Right_Player2()
    {
        boolean correct = true;
        char player = 'X';
        char player2 = 'O';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = player2;

        BoardPosition test1 = new BoardPosition(0,0);

        IGameBoard tester = makeboard(row,col,win);

        tester.placeMarker(test1,player2);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.isPlayerAtPos(test1,player2), correct);

    }

    @Test
    public void testPlaceMarker_Player2_0_0()
    {
        boolean correct = true;
        char player = 'X';
        char player2 = 'O';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][0] = player2;

        BoardPosition test1 = new BoardPosition(0,0);

        IGameBoard tester = makeboard(row,col,win);

        tester.placeMarker(test1,player2);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.isPlayerAtPos(test1,player2), correct);

    }

    @Test
    public void testPlaceMarker_Player_2_2()
    {
        boolean correct = true;
        char player = 'X';
        char player2 = 'O';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[2][2] = player;

        BoardPosition test1 = new BoardPosition(2,2);

        IGameBoard tester = makeboard(row,col,win);

        tester.placeMarker(test1,player);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.isPlayerAtPos(test1,player), correct);

    }

    @Test
    public void testPlaceMarker_Player_0_2()
    {
        boolean correct = true;
        char player = 'X';
        char player2 = 'O';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[0][2] = player;

        BoardPosition test1 = new BoardPosition(0,2);

        IGameBoard tester = makeboard(row,col,win);

        tester.placeMarker(test1,player);

        assertEquals(tester.toString(), makeExpected(row,col,values));
        assertEquals(tester.isPlayerAtPos(test1,player), correct);

    }

    @Test
    public void testPlaceMarker_Player_2_0()
    {
        boolean correct = true;
        char player = 'X';
        char player2 = 'O';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[2][0] = player;

        BoardPosition test1 = new BoardPosition(2,0);

        IGameBoard tester = makeboard(row,col,win);

        tester.placeMarker(test1,player);

        assertEquals(tester.toString(), makeExpected(col,row,values));
        assertEquals(tester.isPlayerAtPos(test1,player), correct);

    }

    @Test
    public void testPlaceMarker_Player_1_1()
    {
        boolean correct = true;
        char player = 'X';
        char player2 = 'O';

        int row = 3;
        int col = 3;
        int win = 3;

        char[][] values = new char[row][col];

        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                values[i][j] = ' ';
            }

        }

        values[1][1] = player;

        BoardPosition test1 = new BoardPosition(1,1);

        IGameBoard tester = makeboard(row,col,win);

        tester.placeMarker(test1,player);

        assertEquals(tester.toString(), makeExpected(row, col, values));
        assertEquals(tester.isPlayerAtPos(test1,player), correct);

    }
}